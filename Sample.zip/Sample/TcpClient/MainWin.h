#ifndef MAINWIN_H
#define MAINWIN_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QProgressBar>
#include <QTcpSocket>

class MainWin : public QWidget
{
    Q_OBJECT
public:
    explicit MainWin(QWidget *parent = nullptr);

signals:

private slots:
    void onBtnSendClicked();
    void onBtnConnectClicked();
    void onSocketConnected();

private:
    QLabel *lblText;
    QLineEdit *lnEditText;
    QPushButton *btnSend;
    QPushButton *btnConnect;
    QProgressBar *prgBarStatus;
    QTcpSocket *socket;

    void init();
};

#endif // MAINWIN_H
