#include "MainWin.h"

#include <QGridLayout>
#include <QHostAddress>

MainWin::MainWin(QWidget *parent) : QWidget(parent)
{
    init();
}

void MainWin::onBtnSendClicked()
{
    QByteArray data = lnEditText->text().toLatin1();
    socket->write(data);
}

void MainWin::onBtnConnectClicked()
{
    QHostAddress address("127.0.0.1");
    socket->connectToHost(address, 2000);
    connect(socket, &QTcpSocket::connected, this, &MainWin::onSocketConnected);
    prgBarStatus->show();
}

void MainWin::onSocketConnected()
{
    btnSend->setEnabled(true);
    prgBarStatus->hide();
}

void MainWin::init()
{
    lblText = new QLabel("Text:");
    lnEditText = new QLineEdit;
    btnSend = new QPushButton("Send");
    btnConnect = new QPushButton("Connect");
    prgBarStatus = new QProgressBar;
    prgBarStatus->setMinimum(0);
    prgBarStatus->setMaximum(0);
    btnSend->setDisabled(true);
    prgBarStatus->hide();

    QGridLayout *gridLay = new QGridLayout;
    gridLay->addWidget(lblText, 0, 0);
    gridLay->addWidget(lnEditText, 0, 1);
    gridLay->addWidget(btnSend, 0, 2);
    gridLay->addWidget(btnConnect, 0, 3);
    gridLay->addWidget(prgBarStatus, 1, 0, 1, 4);

    setLayout(gridLay);

    socket = new QTcpSocket(this);
    connect(btnConnect, &QPushButton::clicked, this, &MainWin::onBtnConnectClicked);
    connect(btnSend, &QPushButton::clicked, this, &MainWin::onBtnSendClicked);
}
