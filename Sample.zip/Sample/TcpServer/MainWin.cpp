#include "MainWin.h"

#include <QVBoxLayout>

MainWin::MainWin(QWidget *parent) : QWidget(parent)
{
    init();
}

void MainWin::onNewConnection()
{
    lblConnectionState->setText("Connection established");
    socket = server->nextPendingConnection();
    connect(socket, &QTcpSocket::readyRead, this, &MainWin::onReadData);
}

void MainWin::onReadData()
{
    QByteArray data = socket->readAll();
    plnTxtLogs->appendPlainText(data);
}

void MainWin::init()
{
    lblConnectionState = new QLabel("Listening...");
    plnTxtLogs = new QPlainTextEdit;

    QVBoxLayout *vBoxLay = new QVBoxLayout;

    vBoxLay->addWidget(lblConnectionState);
    vBoxLay->addWidget(plnTxtLogs);
    setLayout(vBoxLay);

    server = new QTcpServer(this);
    server->listen(QHostAddress::Any, 2000);
    connect(server, &QTcpServer::newConnection, this, &MainWin::onNewConnection);
}
