#ifndef MAINWIN_H
#define MAINWIN_H

#include <QWidget>
#include <QLabel>
#include <QPlainTextEdit>
#include <QTcpServer>
#include <QTcpSocket>

class MainWin : public QWidget
{
    Q_OBJECT
public:
    explicit MainWin(QWidget *parent = nullptr);

signals:

private slots:
    void onNewConnection();
    void onReadData();

private:
    QLabel *lblConnectionState;
    QPlainTextEdit *plnTxtLogs;
    QTcpServer *server;
    QTcpSocket *socket;

    void init();
};

#endif // MAINWIN_H
